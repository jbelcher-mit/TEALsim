/**
 * 
 */
package teal.visualization.processing;

/**
 * @author pbailey
 *
 */

import javax.vecmath.Vector3d;


public interface TColorizer{
	
	public void get(Vector3d in, Vector3d out);
	
}
