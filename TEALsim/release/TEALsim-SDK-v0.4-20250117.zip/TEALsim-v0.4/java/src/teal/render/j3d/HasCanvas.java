package teal.render.j3d;

import java.awt.Canvas;

public interface HasCanvas {
	Canvas getCanvas();
}
