/*
 * TEALsim - MIT TEAL Project
 * Copyright (c) 2004 The Massachusetts Institute of Technology. All rights reserved.
 * Please see license.txt in top level directory for full license.
 * 
 * http://icampus.mit.edu/teal/TEALsim
 * 
 * $Id: TSceneObject.java,v 1.3 2007/07/16 22:04:57 pbailey Exp $ 
 * 
 */

package teal.render.scene;

/** Interface for the
 */

public interface TSceneObject{

    // public void setEnabled(boolean state);
    // public boolean isEnabled();


}
