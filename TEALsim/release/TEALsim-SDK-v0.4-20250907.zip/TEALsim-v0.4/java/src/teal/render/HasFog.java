package teal.render;

public interface HasFog
{
	public boolean isReceivingFog() ;
}
