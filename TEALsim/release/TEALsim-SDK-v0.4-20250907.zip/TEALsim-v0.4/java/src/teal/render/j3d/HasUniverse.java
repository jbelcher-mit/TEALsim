package teal.render.j3d;

import com.sun.j3d.utils.universe.SimpleUniverse;

public interface HasUniverse {
	SimpleUniverse getUniverse();
}
